-- MySQL dump 10.13  Distrib 5.6.23, for osx10.8 (x86_64)
--
-- Host: localhost    Database: us_states
-- ------------------------------------------------------
-- Server version	5.6.23

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `states`
--

DROP TABLE IF EXISTS `states`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `states` (
  `stateName` varchar(20) DEFAULT NULL,
  `population` int(11) DEFAULT NULL,
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `timezone` enum('Pacific','Mountain','Central','Eastern') DEFAULT NULL,
  `averageTemp` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=51 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `states`
--

LOCK TABLES `states` WRITE;
/*!40000 ALTER TABLE `states` DISABLE KEYS */;
INSERT INTO `states` VALUES ('Florida',30000,1,'Eastern',90),('Maine',2000,2,'Eastern',30),('Colorado',2500,3,'Mountain',30),('California',9500,4,'Pacific',70),('Tennessee',3500,5,'Central',50),('Virgina',4500,6,'Eastern',45),('Ohio',2250,7,'Eastern',35),('New York',29250,8,'Eastern',42),('Arizona',2950,9,'Mountain',100),('South Carolina',3050,10,'Eastern',72),('Alabama',21250,11,'Central',65),('Alaska',2250,12,'Mountain',35),('Arkansas',2250,13,'Central',35),('Connectiut',2250,14,'Eastern',35),('Delaware',2250,15,'Eastern',25),('Georgia',2050,16,'Eastern',-35),('Hawaii',2250,17,'Pacific',35),('Idaho',22050,18,'Mountain',25),('Illinois',20250,19,'Mountain',15),('Indiana',29250,20,'Mountain',35),('Iowa',22850,21,'Mountain',35),('Kansas',22950,22,'Central',55),('Kentucky',2250,23,'Central',35),('Louisiana',2,24,'Central',35),('Maryland',24250,25,'Eastern',35),('Massachusetts',22250,26,'Eastern',35),('Michigan',22570,27,'Central',55),('Minnesota',266250,28,'Central',35),('Mississippi',26250,29,'Central',35),('Missouri',22580,30,'Central',95),('Montana',22650,31,'Mountain',35),('Nebraska',250,32,'Mountain',35),('New Hampshire',20,33,'Eastern',35),('New Jersey',29250,34,'Eastern',95),('New Mexico',22850,35,'Central',35),('North Carolina',22590,36,'Eastern',35),('North Dakota',28250,37,'Central',33),('Oklahoma',22650,38,'Central',35),('Oregon',52250,39,'Pacific',35),('Pennsylvania',26250,40,'Eastern',35),('Rhode Island',22550,41,'Eastern',65),('South dakota',244250,42,'Central',38),('Texas',226750,43,'Central',35),('Utah',26250,44,'',33),('Vermont',22560,45,'Eastern',35),('Washington',25250,46,'Pacific',3),('West Virigina',22550,47,'Eastern',5),('Virginia',22550,48,'Eastern',35),('Wisconsin',26250,49,'Central',25),('Wyoming',23250,50,'Mountain',35);
/*!40000 ALTER TABLE `states` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2015-02-12  8:08:32
